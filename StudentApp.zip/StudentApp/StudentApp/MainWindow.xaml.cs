﻿using StudentApp.Helpers;
using StudentApp.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StudentApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainContent.Content = new LoginView();
        }


        //private void Students_Click(object sender, RoutedEventArgs e) => MainContent.Content = new StudentsView();
        //private void Groups_Click(object sender, RoutedEventArgs e) => MainContent.Content = new GroupsView();
        //private void Attendance_Click(object sender, RoutedEventArgs e) => MainContent.Content = new AttendanceView();
        private void Grades_Click(object sender, RoutedEventArgs e) => MainContent.Content = new GradesView();
        private void Reports_Click(object sender, RoutedEventArgs e) => MainContent.Content = new ReportsView();
        private void Notifications_Click(object sender, RoutedEventArgs e) => MainContent.Content = new NotificationsView();

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new LoginView(); // Или что у тебя является "главной" страницей
        }

        private bool CheckAuth()
        {
            if (Session.CurrentUser == null)
            {
                MessageBox.Show("Вы должны авторизоваться!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);

                MainContent.Content = new LoginView();
                return false;
            }
            return true;
        }

        private void Students_Click(object sender, RoutedEventArgs e)
        {
            if (!CheckAuth()) return;
            MainContent.Content = new StudentsView();
        }

        private void Groups_Click(object sender, RoutedEventArgs e)
        {
            if (!CheckAuth()) return;
            MainContent.Content = new GroupsView();
        }

        private void Attendance_Click(object sender, RoutedEventArgs e)
        {
            if (!CheckAuth()) return;
            MainContent.Content = new AttendanceView();
        }

    }
}
