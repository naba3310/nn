﻿using StudentApp.Data;
using StudentApp.Helpers;
using StudentApp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentApp.ViewModels
{
    public class StudentsViewModel
    {
        public ObservableCollection<Student> Students { get; set; }
        public RelayCommand AddCommand { get; }


        public StudentsViewModel()
        {
            Students = new ObservableCollection<Student>();
            Load();
            AddCommand = new RelayCommand(_ => Add());
        }


        private void Load()
        {
            using (var db = new StudentsDbContext())
            {
                Students.Clear();
                foreach (var s in db.Students.Include("Group").ToList())
                    Students.Add(s);
            }
        }


        private void Add()
        {
            using (var db = new StudentsDbContext())
            {
                var g = db.Groups.FirstOrDefault() ?? db.Groups.Add(new Group { Name = "Группа 1" });
                db.SaveChanges();


                db.Students.Add(new Student
                {
                    FirstName = "Имя",
                    LastName = "Фамилия",
                    GroupId = g.Id
                });
                db.SaveChanges();
            }
            Load();
        }
    }
}
