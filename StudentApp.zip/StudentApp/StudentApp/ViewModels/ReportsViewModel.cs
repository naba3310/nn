﻿using StudentApp.Data;
using StudentApp.Helpers;
using StudentApp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace StudentApp.ViewModels
{
    public class ReportsViewModel
    {
        public ObservableCollection<Student> StudentsReport { get; set; }
        public RelayCommand ExportExcelCommand { get; }
        public RelayCommand ExportPdfCommand { get; }


        public ReportsViewModel()
        {
            StudentsReport = new ObservableCollection<Student>();
            Load();


            ExportExcelCommand = new RelayCommand(_ => ExportExcel());
            ExportPdfCommand = new RelayCommand(_ => ExportPdf());
        }


        private void Load()
        {
            using (var db = new StudentsDbContext())
            {
                StudentsReport.Clear();
                foreach (var s in db.Students.Include("Group").ToList())
                    StudentsReport.Add(s);
            }
        }


        private void ExportExcel() => MessageBox.Show("Экспорт в Excel (заглушка)");
        private void ExportPdf() => MessageBox.Show("Экспорт в PDF (заглушка)");
    }
}
