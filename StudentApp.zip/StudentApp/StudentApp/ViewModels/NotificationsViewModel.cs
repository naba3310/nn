﻿using StudentApp.Data;
using StudentApp.Helpers;
using StudentApp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentApp.ViewModels
{
    public class NotificationsViewModel
    {
        public ObservableCollection<Notification> Notifications { get; set; }
        public RelayCommand AddNotificationCommand { get; }


        public NotificationsViewModel()
        {
            Notifications = new ObservableCollection<Notification>();
            Load();
            AddNotificationCommand = new RelayCommand(_ => Add());
        }


        private void Load()
        {
            using (var db = new StudentsDbContext())
            {
                Notifications.Clear();
                foreach (var n in db.Notifications.ToList())
                    Notifications.Add(n);
            }
        }


        private void Add()
        {
            using (var db = new StudentsDbContext())
            {
                db.Notifications.Add(new Notification
                {
                    Message = "Новое уведомление",
                    NotifyDate = DateTime.Now,
                    Done = false
                });
                db.SaveChanges();
            }
            Load();
        }
    }
}
