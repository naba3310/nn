﻿using StudentApp.Data;
using StudentApp.Helpers;
using StudentApp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentApp.ViewModels
{
    public class AttendanceViewModel
    {
        public ObservableCollection<Attendance> Attendance { get; set; }
        public RelayCommand MarkAbsentCommand { get; }


        public AttendanceViewModel()
        {
            Attendance = new ObservableCollection<Attendance>();
            Load();
            MarkAbsentCommand = new RelayCommand(_ => MarkAbsent());
        }


        private void Load()
        {
            using (var db = new StudentsDbContext())
            {
                Attendance.Clear();
                foreach (var a in db.Attendance.Include("Student").ToList())
                    Attendance.Add(a);
            }
        }


        private void MarkAbsent()
        {
            using (var db = new StudentsDbContext())
            {
                var s = db.Students.FirstOrDefault();
                if (s == null) return;


                db.Attendance.Add(new Attendance
                {
                    StudentId = s.Id,
                    Present = false,
                    Date = DateTime.Now
                });
                db.SaveChanges();
            }
            Load();
        }
    }
}
