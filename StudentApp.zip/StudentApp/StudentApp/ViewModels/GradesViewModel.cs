﻿using StudentApp.Data;
using StudentApp.Helpers;
using StudentApp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentApp.ViewModels
{
    public class GradesViewModel
    {
        public ObservableCollection<Grade> Grades { get; set; }
        public RelayCommand AddGradeCommand { get; }


        public GradesViewModel()
        {
            Grades = new ObservableCollection<Grade>();
            Load();
            AddGradeCommand = new RelayCommand(_ => AddGrade());
        }


        private void Load()
        {
            using (var db = new StudentsDbContext())
            {
                Grades.Clear();
                foreach (var g in db.Grades.Include("Student").Include("Subject").ToList())
                    Grades.Add(g);
            }
        }


        private void AddGrade()
        {
            using (var db = new StudentsDbContext())
            {
                var st = db.Students.FirstOrDefault();
                var sub = db.Subjects.FirstOrDefault() ?? db.Subjects.Add(new Subject { Title = "Предмет" });
                db.SaveChanges();


                if (st == null) return;


                db.Grades.Add(new Grade
                {
                    StudentId = st.Id,
                    SubjectId = sub.Id,
                    Value = 5,
                    Date = DateTime.Now
                });
                db.SaveChanges();
            }
            Load();
        }
    }
}
