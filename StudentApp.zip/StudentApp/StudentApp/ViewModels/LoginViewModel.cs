﻿using StudentApp.Data;
using StudentApp.Helpers;
using StudentApp.Models;
using StudentApp.ViewModels;
using StudentApp.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace StudentApp.ViewModels
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        private string _username;
        private string _password;
        private bool _isPasswordVisible;
        private string _errorMessage;

        public event PropertyChangedEventHandler PropertyChanged;

        public string Username
        {
            get => _username;
            set { _username = value; OnPropertyChanged(); }
        }

        public string Password
        {
            get => _password;
            set { _password = value; OnPropertyChanged(); }
        }

        public bool IsPasswordVisible
        {
            get => _isPasswordVisible;
            set { _isPasswordVisible = value; OnPropertyChanged(); }
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set { _errorMessage = value; OnPropertyChanged(); }
        }

        public ICommand TogglePasswordCommand { get; }
        public ICommand LoginCommand { get; }

        public LoginViewModel()
        {
            TogglePasswordCommand = new RelayCommand(_ => TogglePassword());
            LoginCommand = new RelayCommand(_ => Login());
        }

        private void TogglePassword()
        {
            IsPasswordVisible = !IsPasswordVisible;
        }

        private void Login()
        {

            using (var db = new StudentsDbContext())
            {
                var user = db.Users.FirstOrDefault(u =>
                    u.Username == Username &&
                    u.Password == Password);

                if (user == null)
                {
                    MessageBox.Show("User NOT found!");
                    ErrorMessage = "Неверный логин или пароль!";
                    return;
                }
                MessageBox.Show("User FOUND!");
                Session.CurrentUser = user;
            }


            // Находим главное окно
            var mainWindow = Application.Current.Windows
                .OfType<MainWindow>()
                .FirstOrDefault();

            if (mainWindow != null)
            {
                // Меняем контент на StudentsView
                MessageBox.Show("MainWindow NOT FOUND!");
                mainWindow.MainContent.Content = new StudentsView();
            }
            MessageBox.Show("MainWindow FOUND!");
        }


        private void OnPropertyChanged([CallerMemberName] string prop = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
    }

}