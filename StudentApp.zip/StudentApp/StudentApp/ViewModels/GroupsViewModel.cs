﻿using StudentApp.Data;
using StudentApp.Helpers;
using StudentApp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentApp.ViewModels
{
    public class GroupsViewModel
    {
        public ObservableCollection<Group> Groups { get; set; }
        public RelayCommand AddGroupCommand { get; }


        public GroupsViewModel()
        {
            Groups = new ObservableCollection<Group>();
            Load();
            AddGroupCommand = new RelayCommand(_ => AddGroup());
        }


        private void Load()
        {
            using (var db = new StudentsDbContext())
            {
                Groups.Clear();
                foreach (var g in db.Groups.ToList())
                    Groups.Add(g);
            }
        }


        private void AddGroup()
        {
            using (var db = new StudentsDbContext())
            {
                db.Groups.Add(new Group { Name = "Новая группа" });
                db.SaveChanges();
            }
            Load();
        }
    }
}
