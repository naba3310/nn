﻿using StudentApp.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentApp.Data
{
    public class StudentsDbContext : DbContext
    {
        public StudentsDbContext() : base("StudentsDb")
        {
            // ВАЖНО: указываем EF использовать наш инициализатор
            Database.SetInitializer(new StudentsDbInitializer());
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DbSet<Grade> Grades { get; set; }
        public DbSet<Attendance> Attendance { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Notification> Notifications { get; set; }
    }

    // ----- ИНИЦИАЛИЗАТОР -----
    public class StudentsDbInitializer : CreateDatabaseIfNotExists<StudentsDbContext>
    {
        protected override void Seed(StudentsDbContext db)
        {
            // Добавляем администратора
            db.Users.Add(new User
            {
                Username = "admin",
                Password = "1",      // без хэширования, по твоей просьбе
                Role = Role.Admin
            });

            // Пример группы, чтобы не было ошибок
            db.Groups.Add(new Group
            {
                Name = "Группа 1"
            });

            db.SaveChanges();
        }
    }
}
